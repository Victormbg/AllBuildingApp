export const environment = {
  production: false,
  firebase: {

    apiKey: "AIzaSyBC_qevvhRYXUl1K4lUngdDvXbn_wjxN64",
    authDomain: "allbuilding2.firebaseapp.com",
    databaseURL: "https://allbuilding2.firebaseio.com",
    projectId: "allbuilding2",
    storageBucket: "allbuilding2.appspot.com",
    messagingSenderId: "562656809576",
    appId: "1:562656809576:web:3761935e546023a6eba1dd"

  }
};

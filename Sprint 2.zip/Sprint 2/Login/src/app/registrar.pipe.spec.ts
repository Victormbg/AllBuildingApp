import { RegistrarPipe } from './registrar.pipe';

describe('RegistrarPipe', () => {
  it('create an instance', () => {
    const pipe = new RegistrarPipe();
    expect(pipe).toBeTruthy();
  });
});

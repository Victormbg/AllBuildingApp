import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-testelogin',
  templateUrl: './testelogin.page.html',
  styleUrls: ['./testelogin.page.scss'],
})
export class TesteloginPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
